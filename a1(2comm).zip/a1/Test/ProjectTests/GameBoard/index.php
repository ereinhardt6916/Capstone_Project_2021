<?php
require "../Navbar/Navbar.html";
require "../GameBoard/index.html";

?>