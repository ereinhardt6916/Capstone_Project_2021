<?php


require "../Navbar/Navbar.html";
require "BoardTest.html";


?>