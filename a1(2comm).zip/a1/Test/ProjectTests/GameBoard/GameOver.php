<?php


require "../Navbar/Navbar.html";
require "GameOver.html";


?>