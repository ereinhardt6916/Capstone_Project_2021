<?php
require "../Navbar/Navbar.html";
require "../GameSetup/GameSetup.html";

?>